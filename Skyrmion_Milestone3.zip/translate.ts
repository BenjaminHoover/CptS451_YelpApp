function readSakireJson(filename: string) {
	return Deno.readFile(filename) // get raw bytes
		.then((bytes) => new TextDecoder().decode(bytes)) // decode to text
		.then((text) => text.split("\n")) // split to array for each line
		.then(
			(json_strings_arr) =>
				json_strings_arr
					.filter((string) => string.length > 0) // filter out empty lines, which'll break the parser
					.map((json_string) => JSON.parse(json_string)) // feed each line to the JSON parser
		);
}

function timetexttofloat(time: string) {
	const hm = time.split(":");
	return Number(hm[0]) + Number(hm[1]) / 60;
}

console.time("generate user tuples");
Deno.writeFileSync(
	"./user.sql",
	new TextEncoder().encode(`
INSERT INTO users (user_id, name, average_stars, yelping_since, useful, funny, cool, fans) VALUES ${await readSakireJson(
		"./yelp_user.JSON"
	).then((userList) =>
		userList
			.map(
				(user) =>
					`(
						'${user.user_id}',
						'${user.name.replace(/\'/gi, `''`)}',
						${user.average_stars},
						'${user.yelping_since}',
						${user.useful},
						${user.funny},
						${user.cool},
						${user.fans}
					)`
			)
			.join(", \n")
	)};
`)
);
console.timeEnd("generate user tuples");

console.time("generate business tuples");
Deno.writeFileSync(
	"business.sql",
	new TextEncoder().encode(`
INSERT INTO business (business_id, name, is_open, stars, address, city, state, postal_code, latitude, longitude) VALUES ${await readSakireJson(
		"./yelp_business.JSON"
	).then((businesslist) =>
		businesslist
			.map(
				(business) =>
					`(
						'${business.business_id}',
						'${business.name.replace(/\'/gi, `''`)}',
						'${business.is_open}',
						${business.stars},
						'${business.address.replace(/\'/gi, `''`)}',
						'${business.city.replace(/\'/gi, `''`)}',
						'${business.state}',
						'${business.postal_code}',
						${business.latitude},
						${business.longitude}
					)`
			)
			.join(", \n")
	)};
	`)
);
console.timeEnd("generate business tuples");

console.time("generate checkin tuples");
Deno.writeFileSync(
	"checkins.sql",
	new TextEncoder().encode(
		`INSERT INTO business_checkin (business_id, date_time) VALUES ${await readSakireJson(
			"./yelp_checkin.JSON"
		).then((checkinlist) =>
			checkinlist
				.reduce(
					(accum, cur) =>
						accum.concat(
							cur.date.split(",").map((date: string) => {
								return { business_id: cur.business_id, date: date };
							})
						),
					[]
				)
				.map(
					(checkin: { business_id: string; date: string }) =>
						`('${checkin.business_id}', '${checkin.date}')`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate checkin tuples");

console.time("generate tip tuples");
Deno.writeFileSync(
	"tips.sql",
	new TextEncoder().encode(
		`INSERT INTO business_tip (business_id, user_id, date_time, body, likes) VALUES ${await readSakireJson(
			"./yelp_tip.json"
		).then((tiplist) =>
			tiplist
				.map(
					(tip) => `(
					'${tip.business_id}',
					'${tip.user_id}',
					'${tip.date}',
					'${tip.text.replace(/\'/gi, `''`)}',
					${tip.likes}
					)`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate tip tuples");

console.time("generate friend tuples");
Deno.writeFileSync(
	"friends.sql",
	new TextEncoder().encode(
		`INSERT INTO friends (friends_of, friends_with) VALUES ${await readSakireJson(
			"./yelp_user.JSON"
		).then((userlist) =>
			userlist
				.reduce(
					(accum, cur) =>
						accum.concat(
							cur.friends.map((friend: string) => {
								return { friends_of: cur.user_id, friends_with: friend };
							})
						),
					[]
				)
				.map(
					(friendpair: { friends_of: string; friends_with: string }) =>
						`('${friendpair.friends_of}', '${friendpair.friends_with}')`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate friend tuples");

console.time("generate business_hours tuples");
Deno.writeFileSync(
	"business_hours.sql",
	new TextEncoder().encode(
		`INSERT INTO business_hours (business_id, day_of_week, close_time, open_time) VALUES ${await readSakireJson(
			"./yelp_business.json"
		).then((businesslist) =>
			businesslist
				.reduce(
					(accum, cur) =>
						accum.concat(
							Array.from(
								Object.entries(cur.hours as { [key: string]: string })
							).map((dayhours) => {
								const hrs = dayhours[1].split("-");
								return {
									business_id: cur.business_id,
									day_of_week: dayhours[0].substr(0, 2),
									open_time: timetexttofloat(hrs[0]),
									close_time: timetexttofloat(hrs[1]),
								};
							})
						),
					[]
				)
				.map(
					(hours: {
						business_id: string;
						day_of_week: string;
						close_time: number;
						open_time: number;
					}) => `(
					'${hours.business_id}',
					'${hours.day_of_week}',
					${hours.close_time},
					${hours.open_time}
				)`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate business_hours tuples");

console.time("generate business_attrs tuples");
Deno.writeFileSync(
	"./business_attrs.sql",
	new TextEncoder().encode(
		`INSERT INTO business_attrs (business_id, attr_name, attr_value) VALUES ${await readSakireJson(
			"./yelp_business.JSON"
		).then((businesslist) =>
			businesslist
				.reduce(
					(accum, cur) =>
						accum.concat(
							Array.from(
								Object.entries(
									cur.attributes as {
										[key: string]: string | Record<string, unknown>;
									}
								)
							)
								.map((attrpair) => {
									if (typeof attrpair[1] == "object")
										return Array.from(Object.entries(attrpair[1])).map(
											(nattrpair) => {
												return {
													business_id: cur.business_id,
													attr_name: attrpair[0] + "_" + nattrpair[0],
													attr_value: nattrpair[1],
												};
											}
										);

									return [
										{
											business_id: cur.business_id,
											attr_name: attrpair[0],
											attr_value: attrpair[1],
										},
									];
								})
								.reduce((accum, cur) => accum.concat(cur), [])
								.filter((x) => x != null)
						),
					[]
				)
				.filter(
					(attrpair: Record<string, string>) =>
						attrpair.attr_value != "False" &&
						attrpair.attr_value != "no" &&
						attrpair.attr_value != "None"
				)
				.map((attrpair: Record<string, string>) => {
					if (attrpair.attr_value != "True" && attrpair.attr_value != "yes") {
						attrpair.attr_name += "_" + attrpair.attr_value;
						attrpair.attr_value = "True";
					}
					return attrpair;
				})
				.map(
					(attrpair: Record<string, string>) => `(
					'${attrpair.business_id}',
					'${attrpair.attr_name}',
					'${attrpair.attr_value}'
				)`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate business_attrs tuples");

console.time("generate business_good_for_meal tuples");
Deno.writeFileSync(
	"./business_good_for_meal.sql",
	new TextEncoder().encode(
		`INSERT INTO business_good_for_meal (business_id, meal_type) VALUES ${await readSakireJson(
			"./yelp_business.JSON"
		).then((businesslist) =>
			businesslist
				.reduce((accum, cur) => {
					if (cur?.attributes?.GoodForMeal == null) return accum;

					return accum.concat(
						Array.from(Object.entries(cur.attributes.GoodForMeal))
							.filter((x) => x[1] == "True")
							.map((mealpair) => {
								return {
									business_id: cur.business_id,
									meal_type: mealpair[0],
								};
							})
					);
				}, [])
				.map(
					(attrpair: Record<string, string>) => `(
					'${attrpair.business_id}',
					'${attrpair.meal_type}'
				)`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate business_good_for_meal tuples");

console.time("generate business_ambience tuples");
Deno.writeFileSync(
	"./business_ambience.sql",
	new TextEncoder().encode(
		`INSERT INTO business_ambience (business_id, ambience) VALUES ${await readSakireJson(
			"./yelp_business.JSON"
		).then((businesslist) =>
			businesslist
				.reduce((accum, cur) => {
					if (cur?.attributes?.Ambience == null) return accum;
					return accum.concat(
						Array.from(Object.entries(cur.attributes.Ambience))
							.filter((x) => x[1] == "True")
							.map((ambpair) => {
								return {
									business_id: cur.business_id,
									ambience: ambpair[0],
								};
							})
					);
				}, [])
				.map(
					(attrpair: Record<string, string>) => `(
					'${attrpair.business_id}',
					'${attrpair.ambience}'
				)`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate business_ambience tuples");

console.time("generate business_parking tuples");
Deno.writeFileSync(
	"./business_parking.sql",
	new TextEncoder().encode(
		`INSERT INTO business_parking (business_id, parking_type) VALUES ${await readSakireJson(
			"./yelp_business.JSON"
		).then((businesslist) =>
			businesslist
				.reduce((accum, cur) => {
					if (cur?.attributes?.BusinessParking == null) return accum;
					return accum.concat(
						Array.from(Object.entries(cur.attributes.BusinessParking))
							.filter((x) => x[1] == "True")
							.map((parkpair) => {
								return {
									business_id: cur.business_id,
									parking: parkpair[0],
								};
							})
					);
				}, [])
				.map(
					(attrpair: Record<string, string>) => `(
					'${attrpair.business_id}',
					'${attrpair.parking}'
				)`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate business_parking tuples");

console.time("generate business_category tuples");
Deno.writeFileSync(
	"./business_category.sql",
	new TextEncoder().encode(
		`INSERT INTO business_category (business_id, category_name) VALUES ${await readSakireJson(
			"./yelp_business.JSON"
		).then((businesslist) =>
			businesslist
				.reduce((accum, cur) => {
					if (cur?.attributes?.BusinessParking == null) return accum;
					return accum.concat(
						cur.categories.split(", ").map((category: string) => {
							return { category: category, business_id: cur.business_id };
						})
					);
				}, [])
				.map(
					(attrpair: Record<string, string>) => `(
					'${attrpair.business_id}',
					'${attrpair.category.replace(/\'/gi, `''`)}'
				)`
				)
				.join(", \n")
		)};`
	)
);
console.timeEnd("generate business_category tuples");
